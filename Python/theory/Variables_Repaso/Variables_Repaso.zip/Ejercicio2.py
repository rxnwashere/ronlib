#Ejercicio 2 Variables
#Repaso
#Programa hecho por Aarón Cano :)

num1 = float(input("Escribe un número real: "))
num2 = float(input("Escribe un número real: "))
#La función float delante de la función input interpretará la respuesta introducida por el usuario como un número con coma flotante.
#Al ser un número con coma flotante (con decimales), será un número real.

suma = num1 + num2
print(f"El resultado de la suma es {suma}")