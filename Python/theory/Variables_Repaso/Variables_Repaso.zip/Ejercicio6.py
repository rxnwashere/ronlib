print("Texto")
for i in range (1,11):
    print(f"linea {i}")
print("linea N")