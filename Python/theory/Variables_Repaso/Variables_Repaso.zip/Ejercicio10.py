nombre = input("Escribe un nombre: ")
apellido = input("Escribe un apellido: ")
print(f"Tamaño de la cadena {nombre} {apellido} es: ", len(nombre.__add__(" ") + apellido))
#La función len puede servir para medir la longitud de una cadena de texto en Python.