#Ejercicio 1 Variables
#Repaso
#Programa que suma dos números enteros escogidos por el usuario
#IMPORTANTE COMENTAR EJERCICIO

num1 = int(input("Introduce un número entero para sumar: "))
#Primer número elegido. Delante del input se coloca int para indicar que el dato a dar es un número entero.
num2 = int(input("Introduce otro número entero para sumar: "))
#Segundo número elegido.
suma = num1 + num2
#Resultado de la suma asignado en una variable.
print(f"El resultado de la suma es {suma}")
#Mostrar el resultado. Con f antes del texto podemos meter directamente la variables.
#SOLO EN PYTHON 3!