#Ejercicio 4 Variables
#Repaso
#Programa que te devuelve el tipo de valor que almacena la variable.

a = eval(input("Escribe un número o un texto: "))
print(a, type(a))