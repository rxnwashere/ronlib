cadena1 = input("Escribe un nombre: ")
cadena2 = input("Escribe un apellido: ")
print(f"{cadena1} {cadena2}")