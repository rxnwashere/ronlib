cadena1 = "Leonardo"
cadena2 = "Di Caprio"
print(f"{cadena1} {cadena2}")