cadena = "Joanot Martorell, l'autor principal del Tirant lo Blanc"
print(cadena[39:])
#[39:] son los caracteres de la cadena que se cortan, por lo que se imprimiran los restantes.