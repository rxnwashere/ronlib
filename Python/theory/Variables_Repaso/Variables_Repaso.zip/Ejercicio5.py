euros = eval(input("Cuantos euros quieres cambiar a dolares? "))
dolares = euros * 0.85
print(f"{euros:.2f} euros son {dolares:.2f} dolares") 